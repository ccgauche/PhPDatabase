<?php
//Your admin password Change it
function adminKey() {	return "DefaultPassWord";
}
//8 caracters max
function getMasterKey() {
	return "Ta25Pam1";
}
//8 caracters max
function getCriptKey() {
	return "LAms7Pem";
}
//Change It
function getHashKey() {
	return "QmapSJe752LAspQ82de";
}
//All apikeys change it
function getGetKey() {
	return array("all-Yts4Q7al6MsBr754");
}
//All apikeys change it
function getExistsKey() {
	return array("all-Pom1s5Qa6s5Les8");
}
//All apikeys change it
function getPutKey() {
	return array("all-SmaP76S4lOqsx5k");
}
?>